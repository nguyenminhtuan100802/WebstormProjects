class Game{
    constructor(){}
}